import React from "react";
import ReactDom from "react-dom";
import "./css/common.less"; // 引入less

const App = () => {
  return <div className="app">反对是否!!发反反复复!</div>;
};

ReactDom.render(<App />, document.querySelector("#lyproject"));

// 配置和热更新使用（如果不使用该配置的话会刷新页面，注意：热更新不是刷新）
console.log("这是webpack打包的入口文件");
// 还需要在主要的js文件里写入下面这段代码
if (module.hot) {
  // 实现热更新
  module.hot.accept();
}
