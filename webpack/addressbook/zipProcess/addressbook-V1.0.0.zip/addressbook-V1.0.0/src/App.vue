<template>
  <div id="app">
    <div id="AddressBook"></div>
    <AddressBook msg="vue 通讯录组件开发" />
  </div>
</template>

<script>
import AddressBook from "./components/AddressBook/Test.vue";

export default {
  name: "App",
  components: {
    AddressBook
  }
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  color: #2c3e50;
}
</style>
