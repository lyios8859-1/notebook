let BookComponents = {
  name: "AddressBook",
  props: {
    listItem: {
      type: Array,
      default: () => {
        // 对象{} 或者 数组[]使用 函数的方式
        return ["项目1", "项目2"];
      }
    }
  },
  data() {
    return {
      description: "通讯录组建"
    };
  },
  methods: {
    getItem(e) {
      const result = {
        html: e.target.innerHTML
      };
      this.$emit("getItem", { result: result });
    }
  }
};

export default BookComponents;
