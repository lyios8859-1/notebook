<template>
  <div class="AddressBook">
    {{description}}
    <p v-for="(item, index) in listItem"
       :key="index"
       @click="getItem">
      <span>{{item.name ? item.name : item}}==
        {{index}}</span>
    </p>
  </div>
</template>

<style lang="less" scoped>
.AddressBook {
  background: #ccc;
}
</style>

<script>
import Vue from "vue";
import BookComponents from "./BookComponents.js";
// vue 组件是 vue扩展的实例子
export default Vue.extend(BookComponents);
</script>
