<template>
  <div class="index">
    <h1>{{ newMsg }}</h1>
    <hr />
    <AddressBook :listItem="listItem"
                 @getItem="getItemValue"></AddressBook>
  </div>
</template>

<script>
import AddressBook from "./BookComponents.vue";
export default {
  name: "Test",
  props: {
    msg: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      listItem: [
        {
          id: 1,
          name: "Tom"
        },
        {
          id: 2,
          name: "Jerry"
        }
      ],
      // 使用data的方式： 把 props 的值赋值给新的变量，为了不修改 props 的值，修改新的变量即可，否则会有警告
      newMsg: ""
    };
  },
  computed: {
    // 使用computed的方式： 把 props 的值赋值给新的变量，为了不修改 props 的值，修改新的变量即可，否则会有警告
    // 如果给 computed 的计算属性操作需要有setter
    // newMsg() {
    //   return this.msg;
    // }
  },
  methods: {
    getItemValue(value) {
      this.newMsg = value.result.html;
      console.log("value: ", value);
    }
  },
  components: {
    AddressBook
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
